package ir.fanapcamps.elons_toy_car;

public class ElonsToyCar {
    public static ElonsToyCar buy() {
        throw new UnsupportedOperationException("Please implement the (static) RemoteControlCar.buy()  method");
    }

    public String distanceDisplay() {
        throw new UnsupportedOperationException("Please implement the (static) RemoteControlCar.distanceDisplay()  method");
    }

    public String batteryDisplay() {
        throw new UnsupportedOperationException("Please implement the (static) RemoteControlCar.batteryDisplay()  method");
    }

    public void drive() {
        throw new UnsupportedOperationException("Please implement the (static) RemoteControlCar.drive()  method");
    }
}
