package ir.fanapcamps.triangle;

class Triangle {

    Triangle(double side1, double side2, double side3) throws TriangleException {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean isEquilateral() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean isIsosceles() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    boolean isScalene() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}
