package ir.fanapcamps.triangle;

class TriangleException extends Exception {

}
