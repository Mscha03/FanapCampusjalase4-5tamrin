package ir.fanapcamps.robot_simulator;

enum Orientation {

    NORTH, EAST, SOUTH, WEST

}
