package ir.fanapcamps.need_for_speed;

class NeedForSpeed {
    // TODO: define the constructor for the 'NeedForSpeed' class

    public boolean batteryDrained() {
        throw new UnsupportedOperationException("Please implement the NeedForSpeed.batteryDrained() method");
    }

    public int distanceDriven() {
        throw new UnsupportedOperationException("Please implement the NeedForSpeed.distanceDriven() method");
    }

    public void drive() {
        throw new UnsupportedOperationException("Please implement the NeedForSpeed.drive() method");
    }

    public static NeedForSpeed nitro() {
        throw new UnsupportedOperationException("Please implement the (static) NeedForSpeed.nitro() method");
    }
}

class RaceTrack {
    // TODO: define the constructor for the 'RaceTrack' class

    public boolean tryFinishTrack(NeedForSpeed car) {
        throw new UnsupportedOperationException("Please implement the RaceTrack.tryFinishTrack() method");
    }
}
